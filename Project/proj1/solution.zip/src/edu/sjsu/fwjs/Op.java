package edu.sjsu.fwjs;

/**
 * FWJS binary operators.
 */
public enum Op {
    ADD, SUBTRACT, MULTIPLY, DIVIDE, MOD, GT, GE, LT, LE, EQ
}
